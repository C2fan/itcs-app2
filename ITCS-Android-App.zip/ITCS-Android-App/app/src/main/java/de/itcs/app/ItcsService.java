package de.itcs.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Vordergrunddienst „ITCS aktiv“: hält die App am Leben (auch bei gesperrtem Bildschirm),
 * liefert GPS-Positionen an die Webseite und verhindert, dass CPU und WLAN schlafen gehen.
 */
public class ItcsService extends Service implements LocationListener {
    static final String CHANNEL = "itcs_aktiv";
    static final String ACTION_STOP = "de.itcs.app.STOP";
    static final int NOTIFY_ID = 4711;

    /** Empfänger der Positionen (die MainActivity, solange sie existiert). */
    interface PositionSink { void onPosition(Location l); }
    static volatile PositionSink sink;
    static volatile boolean running;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private LocationManager lm;

    static void start(Context c) {
        Intent i = new Intent(c, ItcsService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop(Context c) { c.stopService(new Intent(c, ItcsService.class)); }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            Intent quit = new Intent(this, MainActivity.class).setAction(MainActivity.ACTION_QUIT)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(quit);
            return START_NOT_STICKY;
        }
        Notification n = buildNotification();
        boolean loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFY_ID, n, loc ? ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION : 0);
            else startForeground(NOTIFY_ID, n);
        } catch (Exception e) {
            try { startForeground(NOTIFY_ID, n); } catch (Exception ignored) { stopSelf(); return START_NOT_STICKY; }
        }
        running = true;
        acquireLocks();
        if (loc) startLocation();
        return START_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "ITCS aktiv", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Ortung und Datenübertragung laufen im Hintergrund weiter");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ItcsService.class).setAction(ACTION_STOP), fl);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("ITCS aktiv")
                .setContentText("Ortung und Datenübertragung laufen – auch bei gesperrtem Bildschirm")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "ITCS beenden", stop).build());
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void acquireLocks() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ITCS::aktiv");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
            if (wifiLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    wifiLock = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_HIGH_PERF : WifiManager.WIFI_MODE_FULL, "ITCS::wlan");
                    wifiLock.setReferenceCounted(false);
                    wifiLock.acquire();
                }
            }
        } catch (Exception ignored) { }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private void startLocation() {
        if (lm != null) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this, Looper.getMainLooper());
        } catch (Exception ignored) { }
        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 0, this, Looper.getMainLooper());
        } catch (Exception ignored) { }
    }

    private long lastGps;

    @Override
    public void onLocationChanged(Location l) {
        // GPS hat Vorrang; Netzwerk-Ortung nur, wenn seit 10 s kein GPS kam
        if (LocationManager.GPS_PROVIDER.equals(l.getProvider())) lastGps = System.currentTimeMillis();
        else if (System.currentTimeMillis() - lastGps < 10000) return;
        PositionSink s = sink;
        if (s != null) s.onPosition(l);
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }

    @Override
    public void onDestroy() {
        running = false;
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        lm = null;
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { }
        wakeLock = null; wifiLock = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
