package de.itcs.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.app.PendingIntent;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.media.AudioAttributes;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

/**
 * ITCS als Android-App: zeigt die normale ITCS-Startseite (Auswahl Fahrerterminal / Leitstelle),
 * danach läuft alles wie im Browser – nur dass die App im Hintergrund weiter sendet.
 */
public class MainActivity extends Activity implements ItcsService.PositionSink {
    static final String ACTION_QUIT = "de.itcs.app.QUIT";
    private static final int REQ_PERMS = 1, REQ_FILE = 2, REQ_MIC = 3;
    private PermissionRequest micRequest;   // Sprechfunk: wartet auf die Mikrofon-Freigabe

    private KeepAliveWebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private String baseUrl;

    // Computerstimme: Android-WebView kennt keine Web-Sprachausgabe (speechSynthesis) – daher die
    // Android-Sprachausgabe (TextToSpeech) über window.ITCSApp.speak(text, lautstärke, id).
    private TextToSpeech tts;
    private volatile int ttsState = 0;   // 0 = startet, 1 = bereit, -1 = nicht verfügbar
    private volatile String ttsInfo = "Sprachausgabe startet …";
    private String[] ttsPending;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("itcs", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new KeepAliveWebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // Ansagen dürfen automatisch abspielen
        s.setAllowFileAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString() + " ITCSApp/1.5");
        web.addJavascriptInterface(new Bridge(), "ITCSApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("file") || scheme.equals("about") || scheme.equals("javascript")) return false;
                if ((scheme.equals("http") || scheme.equals("https")) && sameSite(u)) return false;
                // fremde Seiten (z. B. OpenStreetMap-Hinweis) im normalen Browser öffnen
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError(String.valueOf(e.getDescription()));
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) { }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (hasLocation()) cb.invoke(origin, true, true);
                else { geoOrigin = origin; geoCallback = cb; askPermissions(); }
            }

            // Sprechfunk: Mikrofon für die Webseite freigeben (fragt Android erst beim ersten Funken)
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean audio = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                    if (!audio) { req.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE}); return; }
                    if (micRequest != null) micRequest.deny();
                    micRequest = req;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    Intent i = p.createIntent();
                    i.setType("*/*");   // MP3, GPX, KML … – alle Dateitypen zulassen
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(i, "Datei wählen"), REQ_FILE);
                } catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });

        initTts();
        askPermissions();
        if (handleQuit(getIntent())) return;
        loadStart();
    }

    // ------------------------------------------------------------------ Adresse
    private String configuredUrl() {
        String u = prefs.getString("url", "");
        if (u.isEmpty()) u = getString(R.string.itcs_url);
        return u.contains("deine-domain") ? "" : u;
    }

    private void loadStart() {
        baseUrl = configuredUrl();
        if (baseUrl.isEmpty()) web.loadUrl("file:///android_asset/setup.html");
        else web.loadUrl(baseUrl);
    }

    private boolean sameSite(Uri u) {
        if (baseUrl == null || baseUrl.isEmpty()) return false;
        Uri b = Uri.parse(baseUrl);
        return b.getHost() != null && b.getHost().equalsIgnoreCase(u.getHost());
    }

    private void showError(String msg) {
        String q = Uri.encode(msg == null ? "" : msg);
        web.loadUrl("file:///android_asset/setup.html?error=" + q + "&url=" + Uri.encode(baseUrl == null ? "" : baseUrl));
    }

    /** Schnittstelle für die Einrichtungsseite und das ITCS (window.ITCSApp). */
    // ---------------- IBIS über USB-Seriell (1200 Baud, 7 Datenbits, gerade Parität, 2 Stoppbits)
    private UsbSerialPort ibisPort;
    private static final String ACTION_USB = "de.itcs.app.USB_PERMISSION";
    private synchronized String ibisOpenImpl(int baud) {
        try {
            ibisCloseImpl();
            UsbManager um = (UsbManager) getSystemService(USB_SERVICE);
            if (um == null) return "USB wird von diesem Gerät nicht unterstützt";
            List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(um);
            if (drivers.isEmpty()) return "Kein USB-Seriell-Adapter gefunden (FTDI, CP210x, CH340, PL2303) – Adapter per OTG anschließen";
            UsbSerialDriver d = drivers.get(0);
            if (!um.hasPermission(d.getDevice())) {
                Intent it = new Intent(ACTION_USB); it.setPackage(getPackageName());
                PendingIntent pi = PendingIntent.getBroadcast(this, 0, it, Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                um.requestPermission(d.getDevice(), pi);
                return "perm";
            }
            UsbDeviceConnection conn = um.openDevice(d.getDevice());
            if (conn == null) return "USB-Adapter lässt sich nicht öffnen";
            UsbSerialPort p = d.getPorts().get(0);
            p.open(conn);
            p.setParameters(baud > 0 ? baud : 1200, 7, UsbSerialPort.STOPBITS_2, UsbSerialPort.PARITY_EVEN);
            ibisPort = p;
            return "ok";
        } catch (Exception e) { ibisCloseImpl(); return "Fehler: " + e.getMessage(); }
    }
    private synchronized String ibisSendImpl(String hex) {
        if (ibisPort == null) return "nicht verbunden";
        try {
            String h = hex == null ? "" : hex.replaceAll("[^0-9a-fA-F]", "");
            byte[] b = new byte[h.length() / 2];
            for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
            ibisPort.write(b, 2000);
            return "ok";
        } catch (Exception e) { return "Fehler: " + e.getMessage(); }
    }
    private synchronized void ibisCloseImpl() { try { if (ibisPort != null) ibisPort.close(); } catch (Exception ignored) { } ibisPort = null; }

    // ---------------- IBIS-IP / VDV 301 (vorbereitet)
    private volatile String vdvXml = "";
    private volatile ServerSocket vdvServer;
    private synchronized String vdv301StartImpl(int port) {
        vdv301StopImpl();
        try {
            final ServerSocket ss = new ServerSocket(port > 0 ? port : 8301);
            vdvServer = ss;
            new Thread(() -> {
                while (!ss.isClosed()) {
                    try (Socket c = ss.accept()) {
                        c.setSoTimeout(3000);
                        InputStream in = c.getInputStream(); byte[] buf = new byte[4096]; int n = in.read(buf);
                        String req = n > 0 ? new String(buf, 0, n, StandardCharsets.ISO_8859_1) : "";
                        String body = vdvXml.isEmpty() ? "<?xml version=\"1.0\" encoding=\"UTF-8\"?><CustomerInformationService.GetAllDataResponse/>" : vdvXml;
                        if (!req.contains("CustomerInformationService")) body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ITCS><Hinweis>VDV 301 (vorbereitet): /CustomerInformationService/GetAllData</Hinweis></ITCS>";
                        byte[] out = body.getBytes(StandardCharsets.UTF_8);
                        OutputStream os = c.getOutputStream();
                        os.write(("HTTP/1.1 200 OK\r\nContent-Type: text/xml; charset=utf-8\r\nContent-Length: " + out.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));
                        os.write(out); os.flush();
                    } catch (Exception ignored) { }
                }
            }, "vdv301").start();
            return "ok:" + localIp() + ":" + ss.getLocalPort();
        } catch (Exception e) { return "Fehler: " + e.getMessage(); }
    }
    private synchronized void vdv301StopImpl() { try { if (vdvServer != null) vdvServer.close(); } catch (Exception ignored) { } vdvServer = null; }
    private static String localIp() {
        try { for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) for (InetAddress a : Collections.list(ni.getInetAddresses())) if (!a.isLoopbackAddress() && a.getAddress().length == 4) return a.getHostAddress(); } catch (Exception ignored) { }
        return "?";
    }

    private int savedVol = -1;
    private void setCallAudio(boolean on) {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE); if (am == null) return;
            if (on) {
                am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                if (Build.VERSION.SDK_INT >= 31) {
                    for (AudioDeviceInfo d : am.getAvailableCommunicationDevices()) if (d.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) { am.setCommunicationDevice(d); break; }
                } else am.setSpeakerphoneOn(true);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                if (savedVol < 0) savedVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, max, 0);
            } else {
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice(); else am.setSpeakerphoneOn(false);
                if (savedVol >= 0) { am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, savedVol, 0); savedVol = -1; }
                am.setMode(AudioManager.MODE_NORMAL);
            }
        } catch (Exception ignored) { }
    }

    class Bridge {
        @JavascriptInterface public boolean isApp() { return true; }
        @JavascriptInterface public String version() { return "1.6"; }

        /** Computerstimme: Text sprechen (Lautstärke 0…1). Ende kommt als Ereignis „itcs-native-tts“. */
        @JavascriptInterface
        public boolean speak(String text, float vol, String id) {
            if (ttsState == -1 || text == null) return false;
            if (ttsState == 0) { ttsPending = new String[]{text, String.valueOf(vol), id}; return true; }
            runOnUiThread(() -> speakNow(text, vol, id));
            return true;
        }

        @JavascriptInterface
        public boolean speakLang(String text, float vol, String id, String lang) {
            if (ttsState == -1 || text == null) return false;
            if (ttsState == 0) { ttsPending = new String[]{text, String.valueOf(vol), id}; return true; }
            runOnUiThread(() -> speakNow(text, vol, id, lang));
            return true;
        }

        // Sprechfunk-Gespräch: Ton über den Lautsprecher (nicht die Hörmuschel) und laut – sonst hört der Fahrer die Leitstelle kaum
        @JavascriptInterface public void callAudio(final boolean on) { runOnUiThread(() -> setCallAudio(on)); }
        // IBIS-Wagenbus (Test): USB-Seriell-Adapter, Telegramme kommen fertig (mit CR + Prüfbyte) als Hex-Text aus dem Terminal
        @JavascriptInterface public String ibisOpen(int baud) { return ibisOpenImpl(baud); }
        @JavascriptInterface public String ibisSend(String hex) { return ibisSendImpl(hex); }
        @JavascriptInterface public void ibisClose() { ibisCloseImpl(); }
        // IBIS-IP / VDV 301 (vorbereitet): kleiner HTTP-Dienst im Fahrzeugnetz, liefert den zuletzt gesetzten CustomerInformationService-Stand
        @JavascriptInterface public String vdv301Start(int port) { return vdv301StartImpl(port); }
        @JavascriptInterface public void vdv301Set(String xml) { vdvXml = xml == null ? "" : xml; }
        @JavascriptInterface public void vdv301Stop() { vdv301StopImpl(); }
        @JavascriptInterface public void stopSpeak() { try { if (tts != null) tts.stop(); } catch (Exception ignored) { } }
        @JavascriptInterface public String ttsInfo() { return ttsInfo; }
        @JavascriptInterface public int ttsState() { return ttsState; }
        @JavascriptInterface public String getUrl() { return configuredUrl(); }

        @JavascriptInterface
        public void saveUrl(String url) {
            String u = url == null ? "" : url.trim();
            if (u.isEmpty()) return;
            if (!u.toLowerCase(Locale.ROOT).startsWith("http")) u = "https://" + u;
            if (!u.endsWith("/") && !u.toLowerCase(Locale.ROOT).endsWith(".html") && !u.toLowerCase(Locale.ROOT).endsWith(".php")) u += "/";
            prefs.edit().putString("url", u).apply();
            runOnUiThread(MainActivity.this::loadStart);
        }

        @JavascriptInterface public void retry() { runOnUiThread(MainActivity.this::loadStart); }

        @JavascriptInterface
        public void changeUrl() {
            prefs.edit().remove("url").apply();
            runOnUiThread(() -> web.loadUrl("file:///android_asset/setup.html?change=1&url=" + Uri.encode(baseUrl == null ? "" : baseUrl)));
        }

        @JavascriptInterface public void quit() { runOnUiThread(MainActivity.this::quitApp); }
    }

    // ------------------------------------------------------------------ Computerstimme (TextToSpeech)
    private void initTts() {
        try {
            tts = new TextToSpeech(getApplicationContext(), status -> {
                if (status != TextToSpeech.SUCCESS || tts == null) { ttsState = -1; ttsInfo = "Keine Sprachausgabe auf dem Gerät (Einstellungen → Sprachausgabe)"; return; }
                int r = tts.setLanguage(Locale.GERMANY);
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = tts.setLanguage(Locale.GERMAN);
                }
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    ttsInfo = "Deutsch fehlt in der Sprachausgabe (Einstellungen → Sprachausgabe → Sprachdaten installieren)";
                } else {
                    Voice v = null; try { v = tts.getVoice(); } catch (Exception ignored) { }
                    ttsInfo = "Android-Sprachausgabe" + (v != null ? " (" + v.getName() + ")" : "") + " – " + tts.getDefaultEngine();
                }
                try {
                    tts.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)   // gleiche Lautstärke wie die MP3-Ansagen
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                } catch (Exception ignored) { }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { ttsDone(id, true); }
                    @Override public void onError(String id) { ttsDone(id, false); }
                    @Override public void onStop(String id, boolean interrupted) { ttsDone(id, false); }
                });
                ttsState = 1;
                String[] p = ttsPending; ttsPending = null;
                if (p != null) speakNow(p[0], Float.parseFloat(p[1]), p[2]);
            });
        } catch (Exception e) { ttsState = -1; ttsInfo = "Sprachausgabe nicht verfügbar: " + e.getMessage(); }
    }

    private void speakNow(String text, float vol, String id) { speakNow(text, vol, id, null); }

    /** lang: null/„de“ = Deutsch, „en“ = Englisch (z. B. Endhaltestelle zweisprachig) – danach wieder Deutsch. */
    private void speakNow(String text, float vol, String id, String lang) {
        if (tts == null || ttsState != 1) { ttsDone(id, false); return; }
        try { tts.setLanguage("en".equals(lang) ? Locale.UK : Locale.GERMANY); } catch (Exception ignored) { }
        Bundle b = new Bundle();
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, vol)));
        if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, b, id) != TextToSpeech.SUCCESS) ttsDone(id, false);
    }

    private void ttsDone(String id, boolean ok) {
        final String js = "window.dispatchEvent(new CustomEvent('itcs-native-tts',{detail:{id:" + JSONObject.quote(id == null ? "" : id) + ",ok:" + ok + "}}))";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    // ------------------------------------------------------------------ Berechtigungen & Dienst
    private boolean hasLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (!hasLocation()) { need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION); }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) { startService(); return; }
        requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC) {
            boolean ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (micRequest != null) { if (ok) micRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE}); else micRequest.deny(); micRequest = null; }
            return;
        }
        if (code != REQ_PERMS) return;
        boolean loc = hasLocation();
        if (geoCallback != null) { geoCallback.invoke(geoOrigin, loc, loc); geoCallback = null; }
        startService();
        if (!loc) new AlertDialog.Builder(this).setTitle("Standort nicht erlaubt")
                .setMessage("Ohne Standortfreigabe kann das Fahrerterminal das Fahrzeug nicht orten. Die Freigabe kann in den App-Einstellungen nachgeholt werden.")
                .setPositiveButton("OK", null).show();
    }

    private void startService() {
        ItcsService.sink = this;
        if (!ItcsService.running) {
            try { ItcsService.start(this); } catch (Exception ignored) { }
        }
        askBatteryExemption();
    }

    /** Einmalig: Akku-Optimierung für ITCS abschalten lassen (sonst beenden manche Geräte die App trotzdem). */
    @SuppressLint("BatteryLife")
    private void askBatteryExemption() {
        if (prefs.getBoolean("batteryAsked", false)) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        prefs.edit().putBoolean("batteryAsked", true).apply();
        new AlertDialog.Builder(this).setTitle("Im Hintergrund weiterlaufen")
                .setMessage("Damit ITCS bei gesperrtem Bildschirm zuverlässig weiter sendet, bitte im nächsten Schritt die Akku-Optimierung für ITCS ausschalten („Zulassen“).")
                .setPositiveButton("Weiter", (d, w) -> {
                    try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); }
                    catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) { } }
                })
                .setNegativeButton("Später", null).show();
    }

    /** Position vom Dienst an das Fahrerterminal (Webseite) weitergeben. */
    @Override
    public void onPosition(Location l) {
        final String js = String.format(Locale.ROOT,
                "window.dispatchEvent(new CustomEvent('itcs-native-pos',{detail:{lat:%.7f,lon:%.7f,acc:%.1f,t:%d}}))",
                l.getLatitude(), l.getLongitude(), l.hasAccuracy() ? l.getAccuracy() : 30f, l.getTime());
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    // ------------------------------------------------------------------ Lebenszyklus
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    out = new Uri[data.getClipData().getItemCount()];
                    for (int i = 0; i < out.length; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(out);
            fileCallback = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleQuit(intent);
    }

    private boolean handleQuit(Intent i) {
        if (i != null && ACTION_QUIT.equals(i.getAction())) { quitApp(); return true; }
        return false;
    }

    private void quitApp() {
        ItcsService.sink = null;
        ItcsService.stop(this);
        finishAndRemoveTask();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) { web.goBack(); return; }
        // nicht beenden – nur in den Hintergrund, damit Ortung und Senden weiterlaufen
        moveTaskToBack(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ItcsService.sink = this;
        web.onResume();
        web.resumeTimers();
    }

    // Bewusst KEIN web.onPause()/pauseTimers(): die Seite soll im Hintergrund weiterlaufen.

    @Override
    protected void onDestroy() {
        if (ItcsService.sink == this) ItcsService.sink = null;
        if (isFinishing()) ItcsService.stop(this);
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
