package de.itcs.app;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/**
 * WebView, die für die Webseite immer „sichtbar“ bleibt.
 * Normalerweise pausiert/bremst Android die Seite, sobald die App im Hintergrund ist oder der
 * Bildschirm aus geht. So laufen Ortung, Fahrplanlage und Datenübertragung des Terminals weiter.
 */
public class KeepAliveWebView extends WebView {
    public KeepAliveWebView(Context context) { super(context); }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (visibility != View.GONE && visibility != View.INVISIBLE) super.onWindowVisibilityChanged(visibility);
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        if (visibility == View.VISIBLE) super.onVisibilityChanged(changedView, visibility);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        if (hasWindowFocus) super.onWindowFocusChanged(true);
    }
}
