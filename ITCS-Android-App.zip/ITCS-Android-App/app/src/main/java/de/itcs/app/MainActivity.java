package de.itcs.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.Locale;

/**
 * ITCS als Android-App: zeigt die normale ITCS-Startseite (Auswahl Fahrerterminal / Leitstelle),
 * danach läuft alles wie im Browser – nur dass die App im Hintergrund weiter sendet.
 */
public class MainActivity extends Activity implements ItcsService.PositionSink {
    static final String ACTION_QUIT = "de.itcs.app.QUIT";
    private static final int REQ_PERMS = 1, REQ_FILE = 2;

    private KeepAliveWebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private String baseUrl;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("itcs", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new KeepAliveWebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // Ansagen dürfen automatisch abspielen
        s.setAllowFileAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString() + " ITCSApp/1.0");
        web.addJavascriptInterface(new Bridge(), "ITCSApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("file") || scheme.equals("about") || scheme.equals("javascript")) return false;
                if ((scheme.equals("http") || scheme.equals("https")) && sameSite(u)) return false;
                // fremde Seiten (z. B. OpenStreetMap-Hinweis) im normalen Browser öffnen
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError(String.valueOf(e.getDescription()));
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) { }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (hasLocation()) cb.invoke(origin, true, true);
                else { geoOrigin = origin; geoCallback = cb; askPermissions(); }
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    Intent i = p.createIntent();
                    i.setType("*/*");   // MP3, GPX, KML … – alle Dateitypen zulassen
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(i, "Datei wählen"), REQ_FILE);
                } catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });

        askPermissions();
        if (handleQuit(getIntent())) return;
        loadStart();
    }

    // ------------------------------------------------------------------ Adresse
    private String configuredUrl() {
        String u = prefs.getString("url", "");
        if (u.isEmpty()) u = getString(R.string.itcs_url);
        return u.contains("deine-domain") ? "" : u;
    }

    private void loadStart() {
        baseUrl = configuredUrl();
        if (baseUrl.isEmpty()) web.loadUrl("file:///android_asset/setup.html");
        else web.loadUrl(baseUrl);
    }

    private boolean sameSite(Uri u) {
        if (baseUrl == null || baseUrl.isEmpty()) return false;
        Uri b = Uri.parse(baseUrl);
        return b.getHost() != null && b.getHost().equalsIgnoreCase(u.getHost());
    }

    private void showError(String msg) {
        String q = Uri.encode(msg == null ? "" : msg);
        web.loadUrl("file:///android_asset/setup.html?error=" + q + "&url=" + Uri.encode(baseUrl == null ? "" : baseUrl));
    }

    /** Schnittstelle für die Einrichtungsseite und das ITCS (window.ITCSApp). */
    class Bridge {
        @JavascriptInterface public boolean isApp() { return true; }
        @JavascriptInterface public String version() { return "1.0"; }
        @JavascriptInterface public String getUrl() { return configuredUrl(); }

        @JavascriptInterface
        public void saveUrl(String url) {
            String u = url == null ? "" : url.trim();
            if (u.isEmpty()) return;
            if (!u.toLowerCase(Locale.ROOT).startsWith("http")) u = "https://" + u;
            if (!u.endsWith("/") && !u.toLowerCase(Locale.ROOT).endsWith(".html") && !u.toLowerCase(Locale.ROOT).endsWith(".php")) u += "/";
            prefs.edit().putString("url", u).apply();
            runOnUiThread(MainActivity.this::loadStart);
        }

        @JavascriptInterface public void retry() { runOnUiThread(MainActivity.this::loadStart); }

        @JavascriptInterface
        public void changeUrl() {
            prefs.edit().remove("url").apply();
            runOnUiThread(() -> web.loadUrl("file:///android_asset/setup.html?change=1&url=" + Uri.encode(baseUrl == null ? "" : baseUrl)));
        }

        @JavascriptInterface public void quit() { runOnUiThread(MainActivity.this::quitApp); }
    }

    // ------------------------------------------------------------------ Berechtigungen & Dienst
    private boolean hasLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (!hasLocation()) { need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION); }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) { startService(); return; }
        requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERMS) return;
        boolean loc = hasLocation();
        if (geoCallback != null) { geoCallback.invoke(geoOrigin, loc, loc); geoCallback = null; }
        startService();
        if (!loc) new AlertDialog.Builder(this).setTitle("Standort nicht erlaubt")
                .setMessage("Ohne Standortfreigabe kann das Fahrerterminal das Fahrzeug nicht orten. Die Freigabe kann in den App-Einstellungen nachgeholt werden.")
                .setPositiveButton("OK", null).show();
    }

    private void startService() {
        ItcsService.sink = this;
        if (!ItcsService.running) {
            try { ItcsService.start(this); } catch (Exception ignored) { }
        }
        askBatteryExemption();
    }

    /** Einmalig: Akku-Optimierung für ITCS abschalten lassen (sonst beenden manche Geräte die App trotzdem). */
    @SuppressLint("BatteryLife")
    private void askBatteryExemption() {
        if (prefs.getBoolean("batteryAsked", false)) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        prefs.edit().putBoolean("batteryAsked", true).apply();
        new AlertDialog.Builder(this).setTitle("Im Hintergrund weiterlaufen")
                .setMessage("Damit ITCS bei gesperrtem Bildschirm zuverlässig weiter sendet, bitte im nächsten Schritt die Akku-Optimierung für ITCS ausschalten („Zulassen“).")
                .setPositiveButton("Weiter", (d, w) -> {
                    try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); }
                    catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) { } }
                })
                .setNegativeButton("Später", null).show();
    }

    /** Position vom Dienst an das Fahrerterminal (Webseite) weitergeben. */
    @Override
    public void onPosition(Location l) {
        final String js = String.format(Locale.ROOT,
                "window.dispatchEvent(new CustomEvent('itcs-native-pos',{detail:{lat:%.7f,lon:%.7f,acc:%.1f,t:%d}}))",
                l.getLatitude(), l.getLongitude(), l.hasAccuracy() ? l.getAccuracy() : 30f, l.getTime());
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    // ------------------------------------------------------------------ Lebenszyklus
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    out = new Uri[data.getClipData().getItemCount()];
                    for (int i = 0; i < out.length; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(out);
            fileCallback = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleQuit(intent);
    }

    private boolean handleQuit(Intent i) {
        if (i != null && ACTION_QUIT.equals(i.getAction())) { quitApp(); return true; }
        return false;
    }

    private void quitApp() {
        ItcsService.sink = null;
        ItcsService.stop(this);
        finishAndRemoveTask();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) { web.goBack(); return; }
        // nicht beenden – nur in den Hintergrund, damit Ortung und Senden weiterlaufen
        moveTaskToBack(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ItcsService.sink = this;
        web.onResume();
        web.resumeTimers();
    }

    // Bewusst KEIN web.onPause()/pauseTimers(): die Seite soll im Hintergrund weiterlaufen.

    @Override
    protected void onDestroy() {
        if (ItcsService.sink == this) ItcsService.sink = null;
        if (isFinishing()) ItcsService.stop(this);
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
